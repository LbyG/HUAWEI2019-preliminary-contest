#ifndef CAR_H
#define CAR_H

class car {
    public:
    int car_id;
    car();
};

#endif