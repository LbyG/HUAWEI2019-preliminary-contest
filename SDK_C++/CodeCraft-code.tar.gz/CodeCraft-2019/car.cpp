#include "car.h"

car::car() {
    this->car_id = 2;
}